package Model;

public class factData {
	private long data;
	
	public factData() {}
	
	public factData(long data) {
		setData(data);
	}
	
	public long getData() {
		return data;
	}
	
	public void setData(long data) {
		this.data = data;
	}
}
