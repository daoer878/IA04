package Model;

public class multReplyData {
	long result;
	
	public multReplyData() {}
	
	public multReplyData(long result) {
		this.result = result;
	}
	
	public long getResult() {
		return result;
	}
	
	public void setResult(long result) {
		this.result = result;
	}
}
